

function mostrarMensaje() {
    alert("Hola, bienvenido a JavaScript");
}
function cambiarTexto() {
    const titulo = document.getElementById("titulo");
    titulo.textContent = "Texto cambiado con JavaScript";
    titulo.style.color = "purple"

}
let numero = 0;
function sumar() {
    numero++;
    document.getElementById("contador").textContent = numero;
}
function resta() {
    numero--;
    document.getElementById("contador").textContent = numero;
}

function cambiar() {
    document.getElementById("imagen").src = "https://plus.unsplash.com/premium_photo-1761167848633-aac6496f2ea4?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=1175";
}
function volver() {
    document.getElementById("imagen").src = "https://images.unsplash.com/photo-1760889274812-1ff168f0d1ff?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=685";
}